package com.example.data.models

abstract class BaseModel(val type: String)