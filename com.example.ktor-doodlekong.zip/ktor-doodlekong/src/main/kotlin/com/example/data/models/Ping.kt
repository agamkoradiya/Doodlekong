package com.example.data.models

import com.example.other.Constants.TYPE_PING

class Ping : BaseModel(TYPE_PING)