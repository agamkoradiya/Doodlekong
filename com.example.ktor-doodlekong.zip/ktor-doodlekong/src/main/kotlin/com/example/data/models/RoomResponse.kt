package com.example.data.models

data class RoomResponse(
    val name: String,
    val maxPlayers: Int,
    val playerCount: Int
)
