package com.example.data.models

import com.example.other.Constants.TYPE_DISCONNECT_REQUEST

class DisconnectRequest : BaseModel(TYPE_DISCONNECT_REQUEST)