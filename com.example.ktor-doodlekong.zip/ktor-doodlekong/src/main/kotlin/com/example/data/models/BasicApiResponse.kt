package com.example.data.models

data class BasicApiResponse(
    val successful: Boolean,
    val message: String? = null
)
