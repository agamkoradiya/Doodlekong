package com.example.session

data class DrawingSession(
    val clientId: String,
    val sessionId: String
)
